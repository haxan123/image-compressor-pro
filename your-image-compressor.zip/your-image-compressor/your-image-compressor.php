<?php
/**
 * Plugin Name: Image Compressor Pro
 * Plugin URI: https://github.com/haxan123/image-compressor-pro/
 * Description: Compress JPEG and PNG images directly on your server. Reduce image sizes by up to 80% without losing quality.
 * Version: 1.0.0
 * Author: Faiz Hassan
 * Author URI: https://github.com/haxan123/
 * License: GPL v2 or later
 * Text Domain: image-compressor-pro
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ICP_VERSION', '1.0.0');
define('ICP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ICP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ICP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Load required files
require_once ICP_PLUGIN_DIR . 'includes/class-image-processor.php';
require_once ICP_PLUGIN_DIR . 'includes/class-activator.php';
require_once ICP_PLUGIN_DIR . 'includes/class-deactivator.php';
require_once ICP_PLUGIN_DIR . 'admin/class-admin-settings.php';
require_once ICP_PLUGIN_DIR . 'admin/class-bulk-optimizer.php';

// Activation/Deactivation hooks
register_activation_hook(__FILE__, array('ICP_Activator', 'activate'));
register_deactivation_hook(__FILE__, array('ICP_Deactivator', 'deactivate'));

// Initialize plugin
add_action('plugins_loaded', 'icp_init');
function icp_init() {
    // Load text domain for translations
    load_plugin_textdomain('image-compressor-pro', false, dirname(ICP_PLUGIN_BASENAME) . '/languages');
    
    // Initialize admin classes
    if (is_admin()) {
        new ICP_Admin_Settings();
        new ICP_Bulk_Optimizer();
    }
}

// Add media library column
add_filter('manage_media_columns', 'icp_add_media_column');
function icp_add_media_column($columns) {
    $columns['icp_compressed'] = __('Compressed', 'image-compressor-pro');
    return $columns;
}

add_action('manage_media_custom_column', 'icp_display_media_column', 10, 2);
function icp_display_media_column($column_name, $attachment_id) {
    if ($column_name === 'icp_compressed') {
        $is_optimized = get_post_meta($attachment_id, '_icp_optimized', true);
        if ($is_optimized) {
            $original = get_post_meta($attachment_id, '_icp_original_size', true);
            $compressed = get_post_meta($attachment_id, '_icp_compressed_size', true);
            $saved = round((1 - $compressed/$original) * 100, 2);
            echo '<span style="color: green;">✓ Optimized</span><br>';
            echo '<small>Saved: ' . $saved . '%</small>';
        } else {
            echo '<span style="color: gray;">Not optimized</span><br>';
            echo '<button type="button" class="button-link icp-compress-single" data-id="' . $attachment_id . '">Compress</button>';
        }
    }
}

// Enqueue admin scripts
add_action('admin_enqueue_scripts', 'icp_enqueue_admin_scripts');
function icp_enqueue_admin_scripts($hook) {
    // Only load on plugin pages and media library
    if (strpos($hook, 'image-compressor-pro') !== false || $hook === 'upload.php') {
        wp_enqueue_script(
            'icp-admin-scripts',
            ICP_PLUGIN_URL . 'admin/js/admin-scripts.js',
            array('jquery'),
            ICP_VERSION,
            true
        );
        
        wp_localize_script('icp-admin-scripts', 'icp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('icp_bulk_nonce')
        ));
        
        wp_enqueue_style(
            'icp-admin-style',
            ICP_PLUGIN_URL . 'admin/css/admin-style.css',
            array(),
            ICP_VERSION
        );
    }
}

// AJAX handler for single image compression
add_action('wp_ajax_icp_compress_single', 'icp_compress_single_ajax');
function icp_compress_single_ajax() {
    check_ajax_referer('icp_bulk_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_die('Unauthorized');
    }
    
    $attachment_id = intval($_POST['attachment_id']);
    $quality = get_option('icp_quality', 85);
    
    $bulk_optimizer = new ICP_Bulk_Optimizer();
    $result = $bulk_optimizer->optimize_single_image($attachment_id, $quality);
    
    if ($result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result['error']);
    }
}

// AJAX handler for test compression
add_action('wp_ajax_icp_test_compression', 'icp_test_compression_ajax');
function icp_test_compression_ajax() {
    check_ajax_referer('icp_bulk_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error('No image uploaded');
    }
    
    $uploaded_file = $_FILES['image']['tmp_name'];
    $quality = get_option('icp_quality', 85);
    
    $original_size = filesize($uploaded_file);
    
    // Create temp copy for compression
    $temp_file = sys_get_temp_dir() . '/icp_test_' . uniqid() . '.jpg';
    copy($uploaded_file, $temp_file);
    
    $result = ICP_Image_Processor::compress_image($temp_file, $quality);
    
    if ($result) {
        wp_send_json_success(array(
            'original' => size_format($original_size, 2),
            'compressed' => size_format($result['new_size'], 2),
            'saved_percent' => $result['saved_percent']
        ));
    } else {
        wp_send_json_error('Compression failed');
    }
    
    @unlink($temp_file);
}

// AJAX handler for restore all
add_action('wp_ajax_icp_restore_all', 'icp_restore_all_ajax');
function icp_restore_all_ajax() {
    check_ajax_referer('icp_bulk_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    $bulk_optimizer = new ICP_Bulk_Optimizer();
    $count = $bulk_optimizer->reset_all_optimizations();
    
    wp_send_json_success(array('count' => $count));
}

// Add settings link on plugins page
add_filter('plugin_action_links_' . ICP_PLUGIN_BASENAME, 'icp_add_settings_link');
function icp_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=image-compressor-pro">' . __('Settings', 'image-compressor-pro') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// Auto compress on upload
add_filter('wp_handle_upload', 'icp_auto_compress_on_upload');
function icp_auto_compress_on_upload($file) {
    if (get_option('icp_auto_compress', 1)) {
        $mime_type = mime_content_type($file['file']);
        if (in_array($mime_type, array('image/jpeg', 'image/jpg', 'image/png'))) {
            $quality = get_option('icp_quality', 85);
            ICP_Image_Processor::compress_image($file['file'], $quality);
        }
    }
    return $file;
}